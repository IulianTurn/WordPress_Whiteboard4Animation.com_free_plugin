<?php
/*
* Plugin Name: Whiteboard4Animations Free
* Description: Bring life to your website with amazing whiteboard animations
* Version: 1.0.1
* License: GPLv2 or later
* Author: Whiteboard4Animations.com
* Author URI:  https://www.whiteboard4animations.com/
* Plugin URI: https://www.whiteboard4animations.com/wordpress/
*/

define('PLUGIN_VERSION', '1.0.1');

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
// Enqueue scripts and styles
function w4a_remove_homepage_title_script() {
    $settings = get_option('w4a_settings');
    if (is_front_page() && isset($settings['removeTitle']) && $settings['removeTitle'] === 'true') {
        wp_enqueue_script('w4a-remove-title', plugin_dir_url(__FILE__) . 'js/remove_title.js', array('jquery'), PLUGIN_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'w4a_remove_homepage_title_script');

function w4a_scripts() {
    wp_enqueue_script('check-w4a-div', plugins_url('/js/check_w4a_div.js', __FILE__), array(), PLUGIN_VERSION, true);
    wp_enqueue_style('w4a-css', plugins_url('/css/w4a.css', __FILE__), array(), PLUGIN_VERSION);
    wp_enqueue_script('w4a-config', plugins_url('js/w4a.js', __FILE__), array(), PLUGIN_VERSION, true);
    $w4a_settings = get_option('w4a_settings');
    wp_localize_script('w4a-config', 'w4aConfig', array(
        'text' => isset($w4a_settings['text']) ? $w4a_settings['text'] : get_the_title( get_option('page_on_front')),
        'color' => isset($w4a_settings['color']) ? $w4a_settings['color'] :'#000000',
        'size' => isset($w4a_settings['size']) ? $w4a_settings['size'] :'50',
        'stroke' => isset($w4a_settings['stroke']) ? $w4a_settings['stroke'] :'1.8',
        'restart' => isset($w4a_settings['restart']) ? $w4a_settings['restart'] :'false',
        'overflow' => isset($w4a_settings['overflow']) ? $w4a_settings['overflow'] :'true',
        'bgColor' => isset($w4a_settings['bgColor']) ? $w4a_settings['bgColor'] :'transparent',
        'borderStyle' => isset($w4a_settings['borderStyle']) ? $w4a_settings['borderStyle'] :'dotted',
        'borderColor' => isset($w4a_settings['borderColor']) ? $w4a_settings['borderColor'] :'#ffcc48',
        'borderWidth' => isset($w4a_settings['borderWidth']) ? $w4a_settings['borderWidth'] :'10',
        'borderRadius' => isset($w4a_settings['borderRadius']) ? $w4a_settings['borderRadius'] :'20',
        'shadow' => isset($w4a_settings['shadow']) ? $w4a_settings['shadow'] :'true',
        'transparent' => isset($w4a_settings['transparent']) ? $w4a_settings['transparent'] :'true',
        'marginBottom' => isset($w4a_settings['marginBottom']) ? $w4a_settings['marginBottom'] :'-100',
        'hand' => plugin_dir_url(__FILE__) . 'images/hand.png' // Add the image URL here        
    ));
    $home_url = get_home_url();
    wp_localize_script('wordpress-free', 'myHomepage', array(
        'url' => $home_url // Pass the site homepage from PHP as Javascript variable
    ));
    wp_localize_script('check-w4a-div', 'myHomepage', array(
        'url' => $home_url // Pass the site homepage from PHP as Javascript variable
    ));

     // After all enqueue engine.js
    wp_enqueue_script('w4a-engine', plugins_url('js/engine.js', __FILE__), array(), PLUGIN_VERSION, true);
}
add_action('wp_enqueue_scripts', 'w4a_scripts');

//Add styles for table
function w4a_enqueue_admin_styles($hook) {
    // Check if we are on the settings page using the $hook parameter
    if ($hook != 'toplevel_page_w4a-settings') {
        return;
    }
    // Enqueue the CSS file
    wp_enqueue_style('w4a-table-style', plugins_url('/css/table.css', __FILE__), array(), PLUGIN_VERSION);
}
add_action('admin_enqueue_scripts', 'w4a_enqueue_admin_styles');

//ADMIN MENU SCRIPTS

function w4a_add_settings_page() {
    add_menu_page(
        'W4A Settings',           // Page title
        'W4A Settings',           // Menu title
        'manage_options',         // Capability
        'w4a-settings',           // Menu slug
        'w4a_render_settings_page',// Function to display content
        'dashicons-edit',         // Icon 
        10                        // Position
    );
}
add_action('admin_menu', 'w4a_add_settings_page');


function w4a_render_settings_page() {
    ?>
    <div class="wrap">
        <div style="display: flex; flex-direction: row;">
            <div>
                <h1>W4A Settings</h1>
                <form method="post" action="options.php">
                    <?php
                    settings_fields('w4a_settings_group');
                    do_settings_sections('w4a-settings');
                    submit_button();
                    ?>
                </form>
            </div>
            <div style="margin-top: 100px; margin-left: 50px; min-width: 250px; min-height: 250px; height: fit-content; width: fit-content;background-color: wheat;">
                <div class="table">
                    <table id="table_premium">
                        <tr>
                            <th>Features</th>
                            <th>Free&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Premium&nbsp;&nbsp;</th>
        
                        </tr>
                        <tr>
                            <td>Plugin basic settings</td>
                            <td class="checkmark">&#10003;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr>
                        <tr>
                            <td>Animation for Homepage</td>
                            <td class="checkmark">&#10003;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr>
                        <tr>
                            <td>Animation for All Pages</td>
                            <td class="crossmark">&#10007;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr>  
                        <tr>
                            <td>Advanced settings dashboard</td>
                            <td class="crossmark">&#10007;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr>       
                        <tr>
                            <td>Over 30 fonts</td>
                            <td class="crossmark">&#10007;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr>
                        <tr>
                            <td>Many hand options</td>
                            <td class="crossmark">&#10007;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr>
                        <tr>
                            <td>Animations with many lines</td>
                            <td class="crossmark">&#10007;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr> 
                        <tr>
                            <td>Animations with many slides</td>
                            <td class="crossmark">&#10007;</td>
                            <td class="checkmark">&#10003;</td>
                        </tr>        
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
}

function w4a_register_settings() {
    // Register the settings group
    register_setting('w4a_settings_group', 'w4a_settings');
    
    // Add a section
    add_settings_section(
        'w4a_main_section',
        'Whiteboard Animation Customization <span style="font-size:12px;">(Free version)</span>',
        null,
        'w4a-settings'
    );

    // Add text field
    add_settings_field(
        'w4a_text_field',
        'Custom Text',
        'w4a_text_field_callback',
        'w4a-settings',
        'w4a_main_section'
    );
   
    // Add size field
    add_settings_field(
        'w4a_size_field',
        'Font Size',
        'w4a_size_field_callback',
        'w4a-settings',
        'w4a_main_section'
    );
     // Add Restart field
    add_settings_field(
        'w4a_restart_field',
        'Infinite Loop',
        'w4a_restart_field_callback',
         'w4a-settings',
        'w4a_main_section'
         );
    // Add Overflow field
     add_settings_field(
        'w4a_overflow_field',
        'Content Overflow',
        'w4a_overflow_field_callback',
         'w4a-settings',
        'w4a_main_section'
         );
    // Add Stroke field
    add_settings_field(
        'w4a_stroke_field',
        'Stroke Size',
        'w4a_stroke_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Add color field
    add_settings_field(
        'w4a_color_field',
        'Stroke Color',
        'w4a_color_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Add transparent background checkbox field
    add_settings_field(
        'w4a_transparent_field',
        'Background transparent',
        'w4a_transparent_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    
    // Add color field
    add_settings_field(
        'w4a_bgColor_field',
        'Background Color',
        'w4a_bgColor_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Add borderStyle field
    add_settings_field(
        'w4a_borderStyle_field',
        'Border Style',
        'w4a_borderStyle_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Add borderColor field
    add_settings_field(
        'w4a_borderColor_field',
        'Border Color',
        'w4a_borderColor_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Add borderWidth field
    add_settings_field(
        'w4a_borderWidth_field',
        'Border Width',
        'w4a_borderWidth_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Add borderRadius field
    add_settings_field(
        'w4a_borderRadius_field',
        'Border Radius',
        'w4a_borderRadius_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Add Shadow field
    add_settings_field(
        'w4a_shadow_field',
        'Box Shadow',
        'w4a_shadow_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
    // Margin bottom settings field
    add_settings_field(
        'w4a_marginBottom_field',
        'Set margin bottom',
        'w4a_marginBottom_field_callback',
        'w4a-settings',
        'w4a_main_section'
    );
    // Add remove title checkbox field
    add_settings_field(
        'w4a_remove_title_field',
        'Remove Homepage Title',
        'w4a_remove_title_field_callback',
        'w4a-settings',
        'w4a_main_section'
        );
}
add_action('admin_init', 'w4a_register_settings');

function w4a_borderRadius_field_callback() {
    $settings = get_option('w4a_settings');
    $borderRadius = isset($settings['borderRadius']) ? esc_attr($settings['borderRadius']) : 20;
    $options = array(5, 10, 15, 20, 30, 40, 50, 60);
    echo '<select name="w4a_settings[borderRadius]">';
    foreach ($options as $option) {
        $selected = ($borderRadius == $option) ? 'selected' : '';
        printf(
            '<option value="%d" %s>%d</option>',
            esc_attr($option),
            esc_attr($selected),
            esc_html($option)
        );
    }
    echo '</select>';
}


function w4a_marginBottom_field_callback() {
    $settings = get_option('w4a_settings');
    $marginBottom = isset($settings['marginBottom']) ? esc_attr($settings['marginBottom']) : '-100';
    $options = array('10','0', '-10', '-20', '-30', '-40', '-50', '-60', '-70', '-80', '-90', '-100', '-110', '-120', '-130', '-140', '-150', '-160', '-170', '-180', '-190', '-200');
    echo '<select name="w4a_settings[marginBottom]">';
    foreach ($options as $option) {
        $selected = ($marginBottom == $option) ? 'selected' : '';
        echo sprintf(
            '<option value="%s" %s>%s</option>',
            esc_attr($option),
            esc_attr($selected),
            esc_html($option)
        );
    }
    echo '</select>';
}


function w4a_borderWidth_field_callback() {
    $settings = get_option('w4a_settings');
    $borderWidth = isset($settings['borderWidth']) ? esc_attr($settings['borderWidth']) : 5;
    $options = array(1, 2, 3, 5, 10, 15, 20, 30, 40, 50);
    echo '<select name="w4a_settings[borderWidth]">';
    foreach ($options as $option) {
        $selected = ($borderWidth == $option) ? 'selected' : '';
        echo sprintf(
            '<option value="%s" %s>%s</option>',
            esc_attr($option),
            esc_attr($selected),
            esc_html($option)
        );
    }
    echo '</select>';
}


function w4a_borderColor_field_callback() {
    $settings = get_option('w4a_settings');
    $borderColor = isset($settings['borderColor']) ? esc_attr($settings['borderColor']) : '#1c1c1c';
    echo sprintf(
        '<input type="color" name="w4a_settings[borderColor]" value="%s" />',
        esc_attr($borderColor)
    );
}


function w4a_borderStyle_field_callback() {
    $settings = get_option('w4a_settings');
    $borderStyle = isset($settings['borderStyle']) ? esc_attr($settings['borderStyle']) : 'dotted';
    $options = array('dotted', 'dashed', 'solid', 'double', 'ridge', 'groove', 'none');
    echo '<select name="w4a_settings[borderStyle]">';
    foreach ($options as $option) {
        $selected = ($borderStyle === $option) ? 'selected' : '';
        echo sprintf(
            '<option value="%s" %s>%s</option>',
            esc_attr($option),
            esc_attr($selected),
            esc_html($option)
        );
    }
    echo '</select>';
}


function w4a_text_field_callback() {
    $settings = get_option('w4a_settings');
    $default_text = get_the_title(get_option('page_on_front'));
    $text = isset($settings['text']) ? $settings['text'] : $default_text;

    echo sprintf(
        '<input type="text" name="w4a_settings[text]" placeholder="Type here..." value="%s"/>',
        esc_attr($text) 
    );
    echo '<span>&nbsp;&nbsp;&nbsp;Only English standard characters&nbsp;&nbsp;</span>';
}

function w4a_color_field_callback() {
    $settings = get_option('w4a_settings');
    $color = isset($settings['color']) ? $settings['color'] : '#000000';

    echo sprintf(
        '<input type="color" name="w4a_settings[color]" value="%s" />',
        esc_attr($color) 
    );
}

function w4a_bgColor_field_callback() {
    $settings = get_option('w4a_settings');
    $bgColor = isset($settings['bgColor']) ? $settings['bgColor'] : '#ffffff';

    echo sprintf(
        '<input type="color" name="w4a_settings[bgColor]" value="%s" />',
        esc_attr($bgColor) 
    );
}


function w4a_size_field_callback() {
    $settings = get_option('w4a_settings');
    $size = isset($settings['size']) ? $settings['size'] : '48';
    $options = array(48, 42, 36, 28, 24, 18, 14);

    echo '<select name="w4a_settings[size]">';
    foreach ($options as $option) {
        $selected = ($size == $option) ? 'selected' : '';
        echo sprintf(
            '<option value="%s" %s>%s</option>',
            esc_attr($option), 
            esc_attr($selected), 
            esc_html($option) 
        );
    }
    echo '</select>';
}


function w4a_stroke_field_callback() {
    $settings = get_option('w4a_settings');
    $stroke = isset($settings['stroke']) ? $settings['stroke'] : '1.8';
    $options = array(1.2, 1.5, 1.8, 2.5, 3, 3.5);

    echo '<select name="w4a_settings[stroke]">';
    foreach ($options as $option) {
        $selected = ($stroke == $option) ? 'selected' : '';
        echo sprintf(
            '<option value="%s" %s>%s</option>',
            esc_attr($option), 
            esc_attr($selected),
            esc_html($option)
        );
    }
    echo '</select>';
}

function w4a_restart_field_callback() {
    $settings = get_option('w4a_settings');
    $restart = isset($settings['restart']) ? $settings['restart'] : false;
    $checked = $restart ? 'checked' : '';

    echo sprintf(
        '<input type="checkbox" name="w4a_settings[restart]" value="true" %s /> <label for="restart" style="vertical-align: middle;">&nbsp;%s</label>',
        esc_attr($checked), 
        esc_html__('This enables animation looping', 'whiteboard4animations_free') 
    );
}

function w4a_overflow_field_callback() {
    $settings = get_option('w4a_settings');
    $overflow = isset($settings['overflow']) ? $settings['overflow'] : 'true';
    $checked = ($overflow === 'true') ? 'checked' : '';

    echo sprintf(
        '<input type="hidden" name="w4a_settings[overflow]" value="false" />'
    );
    echo sprintf(
        '<input type="checkbox" name="w4a_settings[overflow]" value="true" %s /> <label for="overflow" style="vertical-align: middle;">&nbsp;%s</label>',
        esc_attr($checked), 
        esc_html__('This enables hand overflow', 'whiteboard4animations_free') 
    );
}

function w4a_remove_title_field_callback() {
    $settings = get_option('w4a_settings');
    $removeTitle = isset($settings['removeTitle']) ? $settings['removeTitle'] : 'true';
    $checked = ($removeTitle === 'true') ? 'checked' : '';

    echo sprintf(
        '<input type="hidden" name="w4a_settings[removeTitle]" value="false" />'
    );
    echo sprintf(
        '<input type="checkbox" name="w4a_settings[removeTitle]" value="true" %s /> <label for="removeTitle" style="vertical-align: middle;">&nbsp;%s</label>',
        esc_attr($checked), 
        esc_html__('Remove page title', 'whiteboard4animations_free') 
    );
}

function w4a_shadow_field_callback() {
    $settings = get_option('w4a_settings');
    $shadow = isset($settings['shadow']) ? $settings['shadow'] : 'true';
    $checked = ($shadow === 'true') ? 'checked' : '';

    echo sprintf(
        '<input type="hidden" name="w4a_settings[shadow]" value="false" />'
    );
    echo sprintf(
        '<input type="checkbox" name="w4a_settings[shadow]" value="true" %s /> <label for="shadow" style="vertical-align: middle;">&nbsp;%s</label>',
        esc_attr($checked), 
        esc_html__('This adds shadow around', 'whiteboard4animations_free') 
    );
}

function w4a_transparent_field_callback() {
    $settings = get_option('w4a_settings');
    $transparent = isset($settings['transparent']) ? $settings['transparent'] : 'true';
    $checked = ($transparent === 'true') ? 'checked' : '';

    echo sprintf(
        '<input type="hidden" name="w4a_settings[transparent]" value="false" />'
    );
    echo sprintf(
        '<input type="checkbox" name="w4a_settings[transparent]" value="true" %s /> <label for="transparent" style="vertical-align: middle;">&nbsp;%s</label>',
        esc_attr($checked), 
        esc_html__('Uncheck this to use background colors', 'whiteboard4animations_free') 
    );
}

//Add settings link
function w4a_action_links( $links ) {

	$links = array_merge( array(
		'<a href="' . esc_url( admin_url( 'admin.php?page=w4a-settings' ) ) . '">' . __( 'Settings', 'whiteboard4animations_free' ) . '</a>'
	), $links );

	return $links;

}
add_action( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'w4a_action_links' );

