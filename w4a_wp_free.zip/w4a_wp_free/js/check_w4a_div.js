	const divId = "w4a";
	 currentUrl = window.location.href;
	 actionPage = myHomepage.url;
	if (currentUrl.endsWith("/")) {
		currentUrl = currentUrl.slice(0, -1);
	}
	if (currentUrl == actionPage) {
		if (!document.getElementById(divId)) {
			// Create a new div element
			const newDiv = document.createElement("div");
	
			// Set the ID of the new div
			newDiv.id = divId;
	
			// Find the target insertion point
			const contentDiv = document.getElementById("content");
			const header = document.querySelector("header");
	
			if (contentDiv) {
				// Append the new div before the element with id="content"
				contentDiv.parentNode.insertBefore(newDiv, contentDiv);
			} else if (header) {
				// Append the new div after the header tag
				header.parentNode.insertBefore(newDiv, header.nextSibling);
			} else {
				// If neither exists, append to the end of the body
				document.body.appendChild(newDiv);
			}}
	}else if(document.getElementById(divId)){
		const element = document.getElementById(divId);
		element.remove();
	}	
	

	