(function($) {
    $(document).ready(function() {
        // Hide the title block for common and Elementor-specific page title classes
        $('.wp-block-post-title, .page-title, .entry-title, .post-title, .title, .elementor-page-title h1, .elementor-heading-title').hide();
    });
})(jQuery);
