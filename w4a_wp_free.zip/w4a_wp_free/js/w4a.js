(function () {
	window.config = {
		delay: 0,
		beginTimeDelayed: 0.5,
		font: "font1",
		text: w4aConfig.text || "Homepage custom text", 
		strokeWidth: Number(w4aConfig.stroke) || 1.8,
		strokeColor: w4aConfig.color || "#000000", 
		size: Number(w4aConfig.size) || 48, 
		tracking: 10,
		lineSpacing: 18,
		totalDur: 1.5,
		overflow: JSON.parse(w4aConfig.overflow) ? "visible" : "hidden" || "visible",
		restart: JSON.parse(w4aConfig.restart) || false,
		bgColor: (JSON.parse(w4aConfig.transparent)?"transparent":w4aConfig.bgColor) || "transparent",
		borderStyle: w4aConfig.borderStyle || "dotted",
		borderColor: w4aConfig.borderColor || "#ffcc48",
		borderWidth: Number(w4aConfig.borderWidth) || 10,
		borderRadius: Number(w4aConfig.borderRadius) || 20,
		marginBottom: Number(w4aConfig.marginBottom) || -100,
		hand:
			w4aConfig.hand ||
			"https://www.whiteboard4animations.com/_lib/free/hand100x171_public.png",
	};

	function cssVariables() {
		document.documentElement.style.setProperty("--overflow", config.overflow);
		document.documentElement.style.setProperty("--bgColor", config.bgColor);
		document.documentElement.style.setProperty(
			"--marginBottom",
			config.marginBottom
		);
		document.documentElement.style.setProperty(
			"--borderStyle",
			config.borderStyle
		);
		document.documentElement.style.setProperty(
			"--borderColor",
			config.borderColor
		);
		document.documentElement.style.setProperty(
			"--borderWidth",
			config.borderWidth
		);
		document.documentElement.style.setProperty(
			"--borderRadius",
			config.borderRadius
		);
		//Toggle Box Shadow
		if (document.getElementById("w4a")) {
			document
				.getElementById("w4a")
				.classList.toggle("shadow", w4aConfig.shadow !== "false");
			if (config.text.trim() != "") {
				document.getElementById("w4a").style.display = "block";
			}
		}
	}
	cssVariables();
})();
