=== Whiteboard4Animations Free ===
Tags: Whiteboard, animation, handwriting, slide, drawing
Requires at least: 5.6
Tested up to: 6.7.1
Requires PHP: 5.6
Stable tag: 1.0.1
License: GPLv2 or later

Bring life to your website with the whiteboard animations plugin!

== Description ==

Bring life to your website with the customizable whiteboard animation. Whiteboard4Animations plugin - W4A - is a WordPress plugin developed by whiteboard4animations.com that adds a customizable whiteboard animation on the top of the homepage header. The animation is running in a div with id="w4a" if it exists; if not, it will be created at the top of the page. You can create an empty div with this id="w4a" elsewhere on the page up to you. Many settings available on settings page.

== Upgrade Notice ==
Premium version with extended features is available at: http://www.whiteboard4animations.com

**FEATURES INCLUDE IN FREE VERSION**

*   No setup needed.
*   Whiteboard animations
*   Unlimited text length.
*   Customize font size, stroke size, stroke color.
*   Customize background color, border, and so on.
*   Supports popular page builders.

== Installation ==

1. Unzip the download package.
2. Upload `marquee-running-text` to the `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.

= Manual Plugin Installation =
1. Download W4A-Whiteboard4Animations Plugin to your desktop.
2. If downloaded as a zip archive, extract the Plugin folder to your desktop.
3. With your FTP program, upload the Plugin folder to the `wp-content/plugins` folder in your WordPress directory online.
4. Go to the Plugins screen and find W4A-Whiteboard4Animations Plugin in the list.
5. Click Activate Plugin to activate it.

== Changelog ==

= 1.0.0 =
* First Release.
= 1.0.1 =
* Solved ios safari bug onend not supported.
